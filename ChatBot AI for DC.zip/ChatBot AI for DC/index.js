const { Client, GatewayIntentBits } = require("discord.js");
const { GoogleGenerativeAI } = require("@google/generative-ai"); // Import Gemini API

// Create Discord bot client
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

// Initialize Gemini API (Replace with your API key)
const genAI = new GoogleGenerativeAI("YOUR_GEMINI_API_KEY");

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
});

client.on("messageCreate", async (msg) => {
  if (msg.author.bot) return;
  if (!msg.mentions.has(client.user)) return;

  const userMessage = msg.content.replace(/<@\d+>/g, "").trim();

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-lite" }); // Using Gemini Pro
    const result = await model.generateContent(userMessage);
    const response = result.response.text(); // Extract text response

    msg.reply(response.trim());
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    msg.reply("Sorry, I encountered an error.");
  }
});

client.login("YOUR_DISCORD_BOT_TOKEN"); // Replace with your bot token
